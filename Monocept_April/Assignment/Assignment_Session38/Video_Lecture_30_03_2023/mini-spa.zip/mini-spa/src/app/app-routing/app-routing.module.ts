import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router'
import { HomeComponent } from '../home/home.component';
import { AboutComponent } from '../about/about.component';
import { CarrerComponent } from '../carrer/carrer.component';
import { NotfoundComponent } from '../notfound/notfound.component';

const appRoutes: Routes = [{ path: '', component: HomeComponent },
{ path: 'about', component: AboutComponent },
{ path: 'carrer', component: CarrerComponent },
{ path: '**', component: NotfoundComponent }
]

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forRoot(appRoutes)
  ],
  exports: [RouterModule]
})
export class AppRoutingModule {
}
